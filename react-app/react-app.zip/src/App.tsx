import React from "react";
import "./App.css";
import Layout from "./components/Layout/Layout";

function App() {
  const handleMoreInfo = () => {
    alert("More information clicked!");
  };

  return (
    
    <div>
      <Layout />
    </div>
    
  );
}

export default App;
