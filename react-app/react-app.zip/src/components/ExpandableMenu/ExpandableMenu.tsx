import React from 'react';
import styles from './ExpandableMenu.module.css';

interface ExpandableMenuProps {
  isExpanded: boolean;
  toggleMenu: () => void;
}

const ExpandableMenu: React.FC<ExpandableMenuProps> = ({ isExpanded, toggleMenu }) => {
  return (
    <div className={`${styles.menu} ${isExpanded ? styles.expanded : ''}`}>
      <button onClick={toggleMenu} className={styles.toggleButton}>
        {isExpanded ? '<<' : '>>'}
      </button>
      {isExpanded && (
        <ul className={styles.menuItems}>
          <li>Item 1</li>
          <li>Item 2</li>
          <li>Item 3</li>
        </ul>
      )}
    </div>
  );
};

export default ExpandableMenu;
