import React, { useState } from 'react';
import styles from '../Layout/Layout.module.css';
import ExpandableMenu from '../ExpandableMenu/ExpandableMenu';
import ContentArea from '../ContentArea/ContentArea';

const Layout: React.FC = () => {
  const [isMenuExpanded, setIsMenuExpanded] = useState(false);

  const toggleMenu = () => {
    setIsMenuExpanded(!isMenuExpanded);
  };

  return (
    <div className={styles.layout}>
      <ExpandableMenu isExpanded={isMenuExpanded} toggleMenu={toggleMenu} />
      <ContentArea />
    </div>
  );
};

export default Layout;
